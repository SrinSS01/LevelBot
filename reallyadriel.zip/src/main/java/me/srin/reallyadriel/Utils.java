package me.srin.reallyadriel;

import java.util.concurrent.ScheduledThreadPoolExecutor;

public class Utils {
    public static final ScheduledThreadPoolExecutor EXECUTOR = new ScheduledThreadPoolExecutor(2);
}
