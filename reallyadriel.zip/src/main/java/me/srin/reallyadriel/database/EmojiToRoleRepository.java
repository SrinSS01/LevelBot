package me.srin.reallyadriel.database;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmojiToRoleRepository extends JpaRepository<EmojiToRole, EmojiToRole.ID> {

}